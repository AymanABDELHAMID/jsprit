Name   #Customers   #Stations   MaxTime(min.)   MaxDistance(miles)   Speed(miles\min.)   ServiceTime(min.)   RefuelTime(min.)

NodeID   NodeType(d=depot, f=refueling_station, c=customer)   Longitude   Latitude